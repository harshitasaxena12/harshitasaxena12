# Loan Eligibility Classification & EDA & Stream lit

This project gives an insignt into the exploration, classification and stream lit implementation

### Content
* Exploratory data anaysis
* Data cleaning 
* Model Training
* Model Test (predicting and see the performance of different models
* Export model for external implementation
* Implementing model using stream lit
* Cool Blog post to give a brief explanation of what we did
* And the code 

### [Check out the blog post](https://medium.com/@nmuchelemba/loan-eligibility-classification-eda-a-cool-stream-lit-app-c814cc7947b9)


![alt text](https://github.com/nicholas124/Loan-project/blob/master/loan-app.PNG?raw=true)

# Conclusion
This notebook was a good way for me to shapen my skills in the art of performing EDA and model training and implementation
of the dream house dataset from Kaggle.
